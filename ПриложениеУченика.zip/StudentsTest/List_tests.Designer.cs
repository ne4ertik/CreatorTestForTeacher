﻿namespace StudentsTest
{
    partial class List_tests
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataBaseTestSchoolDataSet = new StudentsTest.DataBaseTestSchoolDataSet();
            this.тестыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.тестыTableAdapter = new StudentsTest.DataBaseTestSchoolDataSetTableAdapters.ТестыTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.button_selectTest = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataBaseTestSchoolDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.тестыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataBaseTestSchoolDataSet
            // 
            this.dataBaseTestSchoolDataSet.DataSetName = "DataBaseTestSchoolDataSet";
            this.dataBaseTestSchoolDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // тестыBindingSource
            // 
            this.тестыBindingSource.DataMember = "Тесты";
            this.тестыBindingSource.DataSource = this.dataBaseTestSchoolDataSet;
            // 
            // тестыTableAdapter
            // 
            this.тестыTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift SemiBold", 16F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(49)))), ((int)(((byte)(114)))));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 33);
            this.label1.TabIndex = 4;
            this.label1.Text = "Список тестов";
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(18, 62);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(494, 411);
            this.listView1.TabIndex = 5;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // button_selectTest
            // 
            this.button_selectTest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(49)))), ((int)(((byte)(114)))));
            this.button_selectTest.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_selectTest.Font = new System.Drawing.Font("Bahnschrift SemiBold", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_selectTest.ForeColor = System.Drawing.Color.White;
            this.button_selectTest.Location = new System.Drawing.Point(540, 62);
            this.button_selectTest.Name = "button_selectTest";
            this.button_selectTest.Size = new System.Drawing.Size(357, 66);
            this.button_selectTest.TabIndex = 6;
            this.button_selectTest.Text = "Выбрать";
            this.button_selectTest.UseVisualStyleBackColor = false;
            this.button_selectTest.Click += new System.EventHandler(this.button_selectTest_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::StudentsTest.Properties.Resources.Nerd_amico;
            this.pictureBox1.Location = new System.Drawing.Point(552, 134);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(323, 330);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // List_tests
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(909, 504);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_selectTest);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "List_tests";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "List_tests";
            ((System.ComponentModel.ISupportInitialize)(this.dataBaseTestSchoolDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.тестыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DataBaseTestSchoolDataSet dataBaseTestSchoolDataSet;
        private System.Windows.Forms.BindingSource тестыBindingSource;
        private DataBaseTestSchoolDataSetTableAdapters.ТестыTableAdapter тестыTableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button button_selectTest;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}