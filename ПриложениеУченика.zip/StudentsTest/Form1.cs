﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;


namespace StudentsTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           


        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
           

            // Сохраняем данные вводимые учеником
                string Familia= TB_Familia.Text;
                string Name = TB_Name.Text;
                string Class_st = CB_NumberClass.Text + CB_Letter.Text;

            // Проверяем заполнены ли все поля
            if ((Familia == "") | (Name == "") | (CB_NumberClass.Text == "")|(CB_Letter.Text ==""))
                {
                    MessageBox.Show("Заполните все поля");
                }

            else try {

                    // Делаем запрос к таблице БД где находятся данные пользователя
                    // 
                    OleDbConnection conn = new System.Data.OleDb.OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.16.0;Data Source=C:\My works for college\CreatorTestForTeacher\DataBaseTestSchool.accdb");
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand("select * from Пользователи where Фамилия = '" + Familia + "' and Имя = '" + Name + "' and Класс = '" + Class_st + "' and Роль = 'Ученик' ", conn);

                    OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    // Предоставления доступа если пользователь существует
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++) { 
                      
                                MessageBox.Show("Вы вошли как " + dt.Rows[i][1] + " " + dt.Rows[i][2]);
                            int userId = Convert.ToInt32(dt.Rows[0]["ID_user"]);

                            List_tests form = new List_tests(userId);
                                    form.Show();
                                    this.Hide();
                         
                            }
                        }
                }
                catch {

                    MessageBox.Show("Ошибка авторизации");
                }

        }
    }
}
