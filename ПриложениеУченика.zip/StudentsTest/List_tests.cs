﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Serialization;

namespace StudentsTest
{
    public partial class List_tests : Form
    {

        int _userId;
        public List_tests(int userId)
        {
            InitializeComponent();

          _userId = userId;
        

        listView1.View = View.Details;
        listView1.Columns.Add("ID", 50);
        listView1.Columns.Add("Название", 200);
        listView1.Columns.Add("Кол-во вопросов", 100);
        listView1.FullRowSelect = true;
        
        LoadTestsFromDatabase();
    }

    private void LoadTestsFromDatabase()
    {
        try
        {
            using (OleDbConnection conn = new OleDbConnection(
                @"Provider=Microsoft.ACE.OLEDB.16.0;Data Source=C:\My works for college\CreatorTestForTeacher\DataBaseTestSchool.accdb"))
            {
                conn.Open();

                string query = "SELECT ID_test, Название, [Количество вопросов], [Путь к файлу] FROM Тесты";

                using (OleDbCommand cmd = new OleDbCommand(query, conn))
                {
                

                    using (OleDbDataReader reader = cmd.ExecuteReader())
                    {
                        listView1.Items.Clear();

                        while (reader.Read())
                        {
                            ListViewItem item = new ListViewItem(reader["ID_test"].ToString());
                            item.SubItems.Add(reader["Название"].ToString());

                            item.SubItems.Add(reader["Количество вопросов"].ToString());
                            item.Tag = reader["Путь к файлу"].ToString(); // Сохраняем путь к файлу в Tag

                            listView1.Items.Add(item);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка загрузки тестов: {ex.Message}", "Ошибка",
                          MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

   

    protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private void button_selectTest_Click(object sender, EventArgs e)
        {
            // Проверяем, выбран ли какой-то тест
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Выберите тест из списка", "Информация",
                              MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                // Получаем ID выбранного теста (первая колонка в ListView)
                int selectedTestId = int.Parse(listView1.SelectedItems[0].Text);

                // Получаем путь к файлу теста из свойства Tag
                string testFilePath = listView1.SelectedItems[0].Tag.ToString();

                // Создаем и показываем форму Test_form, передавая параметры
                Test_form testForm = new Test_form(_userId, selectedTestId, testFilePath);
                this.Hide(); // Скрываем текущую форму
                testForm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии теста: {ex.Message}", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }

}

